// Esperar a que el contenido del DOM esté completamente cargado
document.addEventListener("DOMContentLoaded", () => {
    // Cambiar la clase activa en la barra de navegación
    const navLinks = document.querySelectorAll("nav a");
    navLinks.forEach(link => {
        link.addEventListener("click", event => {
            // Eliminar la clase activa actual
            navLinks.forEach(nav => nav.classList.remove("active"));
            // Agregar la clase activa al enlace actual
            event.target.classList.add("active");
        });
    });

    // Mostrar un mensaje emergente al hacer clic en un servicio
    const serviceItems = document.querySelectorAll(".service");
    serviceItems.forEach(item => {
        item.addEventListener("click", () => {
            const serviceName = item.querySelector("h2").textContent;
            alert(`Has seleccionado el servicio: ${serviceName}`);
        });
    });

    // Cambiar dinámicamente el contenido del héroe al pasar el mouse por un servicio
    serviceItems.forEach(item => {
        item.addEventListener("mouseover", () => {
            const heroTitle = document.querySelector(".hero h1");
            const heroDescription = document.querySelector(".hero p");

            const serviceName = item.querySelector("h2").textContent;
            const serviceDescription = item.querySelector("p").textContent;

            heroTitle.textContent = serviceName;
            heroDescription.textContent = serviceDescription;
        });

        item.addEventListener("mouseout", () => {
            // Restablecer el contenido original del héroe
            const heroTitle = document.querySelector(".hero h1");
            const heroDescription = document.querySelector(".hero p");

            heroTitle.textContent = "Relájate, Renueva, Revive";
            heroDescription.textContent = "Descubre la experiencia única que mereces.";
        });
    });

    // Enviar la información del formulario para agendar una cita por correo electrónico
    const appointmentForm = document.querySelector("#appointment-form");
    if (appointmentForm) {
        appointmentForm.addEventListener("submit", event => {
            event.preventDefault(); // Evitar el envío por defecto

            const formData = new FormData(appointmentForm);
            const name = formData.get("name");
            const email = formData.get("email");
            const date = formData.get("date");
            const service = formData.get("service");

            if (name && email && date && service) {
                // Configurar el correo
                const emailData = {
                    to: "charlyvarela773@gmail.com",
                    subject: "Nueva cita agendada",
                    body: `Nombre: ${name}\nCorreo: ${email}\nFecha: ${date}\nServicio: ${service}`
                };

                // Usar Email API (simulación)
                fetch("https://example-email-api.com/send", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(emailData)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(`Gracias por agendar tu cita, ${name}. Hemos enviado los detalles de tu cita a ${email}.`);
                        appointmentForm.reset(); // Limpiar el formulario
                    } else {
                        alert("Hubo un problema al enviar tu cita. Por favor, inténtalo de nuevo más tarde.");
                    }
                })
                .catch(error => {
                    console.error("Error al enviar el correo:", error);
                    alert("No se pudo procesar tu cita. Por favor, inténtalo más tarde.");
                });
            } else {
                alert("Por favor, completa todos los campos antes de enviar.");
            }
        });
    }
});
